import { BrowserRouter } from "react-router-dom";

<BrowserRouter basename="/Aniash-tool">
  <App />
</BrowserRouter>
